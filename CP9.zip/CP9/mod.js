let startTime;
let intervalId;
let running = false;

function startStopwatch() {
    if (!running) {
        startTime = Date.now();
        intervalId = setInterval(updateDisplay, 1000);
        running = true;
    }
}
function startStopwatch1() {
    if (!running) {
        startTime = Date.now();
        intervalId = setInterval(updateDisplay1, 1000);
        running = true;
    }
}
function startStopwatch2() {
    if (!running) {
        startTime = Date.now();
        intervalId = setInterval(updateDisplay2, 1000);
        running = true;
    }
}
function startStopwatch3() {
    if (!running) {
        startTime = Date.now();
        intervalId = setInterval(updateDisplay3, 1000);
        running = true;
    }
}
function startStopwatch4() {
    if (!running) {
        startTime = Date.now();
        intervalId = setInterval(updateDisplay4, 1000);
        running = true;
    }
}

function stopStopwatch() {
    if (running) {
        clearInterval(intervalId);
        running = false;
    }
}

function resetStopwatch() {
    stopStopwatch();
    document.getElementById("display").innerText = "00:00:00";
}

function resetStopwatch1() {
    stopStopwatch();
    document.getElementById("display1").innerText = "00:00:00";
}

function resetStopwatch2() {
    stopStopwatch();
    document.getElementById("display2").innerText = "00:00:00";
}

function resetStopwatch3() {
    stopStopwatch();
    document.getElementById("display3").innerText = "00:00:00";
}

function resetStopwatch4() {
    stopStopwatch();
    document.getElementById("display4").innerText = "00:00:00";
}
function updateDisplay() {
    const currentTime = Date.now();
    const elapsedTime = currentTime - startTime;
    const seconds = Math.floor(elapsedTime / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    const formattedHours = String(hours).padStart(2, "0");
    const formattedMinutes = String(minutes % 60).padStart(2, "0");
    const formattedSeconds = String(seconds % 60).padStart(2, "0");

    document.getElementById("display").innerText = `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
}

document.getElementById("start").addEventListener("click", startStopwatch);
document.getElementById("stop").addEventListener("click", stopStopwatch);
document.getElementById("reset").addEventListener("click", resetStopwatch);

function updateDisplay1() {
    const currentTime = Date.now();
    const elapsedTime = currentTime - startTime;
    const seconds = Math.floor(elapsedTime / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    const formattedHours = String(hours).padStart(2, "0");
    const formattedMinutes = String(minutes % 60).padStart(2, "0");
    const formattedSeconds = String(seconds % 60).padStart(2, "0");

    document.getElementById("display1").innerText = `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
}

document.getElementById("start1").addEventListener("click", startStopwatch1);
document.getElementById("stop1").addEventListener("click", stopStopwatch);
document.getElementById("reset1").addEventListener("click", resetStopwatch1);

function updateDisplay2() {
    const currentTime = Date.now();
    const elapsedTime = currentTime - startTime;
    const seconds = Math.floor(elapsedTime / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    const formattedHours = String(hours).padStart(2, "0");
    const formattedMinutes = String(minutes % 60).padStart(2, "0");
    const formattedSeconds = String(seconds % 60).padStart(2, "0");

    document.getElementById("display2").innerText = `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
}

document.getElementById("start2").addEventListener("click", startStopwatch2);
document.getElementById("stop2").addEventListener("click", stopStopwatch);
document.getElementById("reset2").addEventListener("click", resetStopwatch2);

function updateDisplay3() {
    const currentTime = Date.now();
    const elapsedTime = currentTime - startTime;
    const seconds = Math.floor(elapsedTime / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    const formattedHours = String(hours).padStart(2, "0");
    const formattedMinutes = String(minutes % 60).padStart(2, "0");
    const formattedSeconds = String(seconds % 60).padStart(2, "0");

    document.getElementById("display3").innerText = `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
}

document.getElementById("start3").addEventListener("click", startStopwatch3);
document.getElementById("stop3").addEventListener("click", stopStopwatch);
document.getElementById("reset3").addEventListener("click", resetStopwatch3);

function updateDisplay4() {
    const currentTime = Date.now();
    const elapsedTime = currentTime - startTime;
    const seconds = Math.floor(elapsedTime / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    const formattedHours = String(hours).padStart(2, "0");
    const formattedMinutes = String(minutes % 60).padStart(2, "0");
    const formattedSeconds = String(seconds % 60).padStart(2, "0");

    document.getElementById("display4").innerText = `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
}

document.getElementById("start4").addEventListener("click", startStopwatch4);
document.getElementById("stop4").addEventListener("click", stopStopwatch);
document.getElementById("reset4").addEventListener("click", resetStopwatch4);


